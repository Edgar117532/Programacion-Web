Estructura del proyecto

mi-proyecto/
│── docker-compose.yml
│── Dockerfile
│── package.json
│── app.js
│── models/
│   └── todo.js
│── routes/
│   └── index.js
│── views/
│   └── index.pug
│── public/
│   └── stylesheets/style.css

1. Dockerfile
FROM node:18-alpine

# Crear directorio de trabajo
WORKDIR /usr/src/app

# Copiar package.json e instalar dependencias
COPY package*.json ./
RUN npm install -g nodemon && npm install

# Copiar todo el proyecto
COPY . .

# Exponer puerto
EXPOSE 3000

# Comando por defecto
CMD ["npm", "run", "dev"]

2. docker-compose.yml
version: "3.8"
services:
  app:
    build: .
    container_name: node-app
    restart: unless-stopped
    ports:
      - "3000:3000"
    volumes:
      - .:/usr/src/app
    depends_on:
      - mongodb
    command: npm run dev

  mongodb:
    image: mongo:6.0
    container_name: mongo-db
    restart: unless-stopped
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db

volumes:
  mongo_data:

3. package.json
{
  "name": "mi-proyecto",
  "version": "1.0.0",
  "main": "app.js",
  "scripts": {
    "start": "node app.js",
    "dev": "nodemon app.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.6.0",
    "pug": "^3.0.2"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}

4. app.js
var express = require("express");
var mongoose = require("mongoose");
var path = require("path");
var indexRouter = require("./routes/index");

var app = express();

// Conectar a MongoDB (usando el nombre del servicio en docker-compose)
mongoose.connect("mongodb://mongodb:27017/todos", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

var db = mongoose.connection;
db.on("error", console.error.bind(console, "❌ Error de conexión:"));
db.once("open", () => {
  console.log("✅ Conectado a MongoDB");
});

// Configuración de vistas
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

// Middleware
app.use(express.static(path.join(__dirname, "public")));
app.use("/", indexRouter);

// Iniciar servidor
app.listen(3000, () => {
  console.log("🚀 Servidor corriendo en http://localhost:3000");
});

5. models/todo.js
const mongoose = require("mongoose");

const todoSchema = new mongoose.Schema({
  description: String,
  complete: Boolean,
});

module.exports = mongoose.model("Todo", todoSchema);

6. routes/index.js
var express = require("express");
var router = express.Router();
var Todo = require("../models/todo");

// Página principal: lista de todos
router.get("/", async (req, res) => {
  const todos = await Todo.find();
  res.render("index", { title: "Mi Lista de Tareas", todos });
});

module.exports = router;

7. views/index.pug
doctype html
html
  head
    title= title
    link(rel="stylesheet", href="/stylesheets/style.css")
  body
    h1= title
    if todos.length
      ul
        each todo in todos
          li(class=todo.complete ? "complete" : "")= todo.description
    else
      p No hay tareas todavía

8. public/stylesheets/style.css
body {
  font-family: Arial, sans-serif;
  margin: 20px;
}

ul {
  list-style: none;
  padding: 0;
}

li {
  padding: 10px;
  margin-bottom: 5px;
  background: #f4f4f4;
  border-radius: 5px;
}

li.complete {
  text-decoration: line-through;
  color: gray;
}

🚀 Cómo ejecutar

Clona este proyecto en tu máquina.

Ejecuta:

docker-compose up --build


Abre en el navegador:
👉 http://localhost:3000

📝 Insertar datos de prueba en MongoDB

Abre otra terminal y ejecuta dentro del contenedor MongoDB:

docker exec -it mongo-db mongosh

use todos
db.todos.insertMany([
  { description: "Hacer la tarea", complete: false },
  { description: "Comprar pan", complete: true }
])


Refresca el navegador y verás las tareas.
