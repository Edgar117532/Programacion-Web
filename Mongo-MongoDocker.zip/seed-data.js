const mongoose = require("mongoose")

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/todos"

const todoSchema = new mongoose.Schema({
  description: { type: String, required: true },
  complete: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
})

const Todo = mongoose.model("Todo", todoSchema)

const sampleTodos = [
  { description: "Completar el proyecto de MongoDB", complete: false },
  { description: "Revisar documentación de Mongoose", complete: true },
  { description: "Implementar autenticación", complete: false },
  { description: "Escribir tests unitarios", complete: false },
  { description: "Desplegar en producción", complete: false },
]

async function seedData() {
  try {
    await mongoose.connect(MONGODB_URI)
    console.log("✅ Conectado a MongoDB")

    // Limpiar datos existentes
    await Todo.deleteMany({})
    console.log("🧹 Datos anteriores eliminados")

    // Insertar datos de prueba
    await Todo.insertMany(sampleTodos)
    console.log(`📝 ${sampleTodos.length} tareas de prueba insertadas`)

    process.exit(0)
  } catch (error) {
    console.error("❌ Error:", error)
    process.exit(1)
  }
}

seedData()
