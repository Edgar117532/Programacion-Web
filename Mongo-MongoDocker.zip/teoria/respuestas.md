# Teoría MongoDB - Respuestas y Conceptos

## Conceptos Fundamentales

### ¿Qué es MongoDB?
MongoDB es una base de datos NoSQL orientada a documentos que almacena datos en formato BSON (Binary JSON). Es altamente escalable y flexible, ideal para aplicaciones modernas.

### Características Principales
- **Esquema flexible**: No requiere estructura fija
- **Escalabilidad horizontal**: Sharding nativo
- **Consultas ricas**: Soporte para consultas complejas
- **Índices**: Múltiples tipos de índices para optimización
- **Agregación**: Pipeline potente para análisis de datos

## Glosario

### Términos Básicos
- **Documento**: Unidad básica de datos, equivalente a una fila en SQL
- **Colección**: Grupo de documentos, equivalente a una tabla en SQL
- **Base de datos**: Contenedor de colecciones
- **Campo**: Par clave-valor dentro de un documento
- **_id**: Identificador único automático de cada documento

### Operaciones CRUD
- **Create**: `insertOne()`, `insertMany()`
- **Read**: `find()`, `findOne()`
- **Update**: `updateOne()`, `updateMany()`, `replaceOne()`
- **Delete**: `deleteOne()`, `deleteMany()`

### Agregación
- **Pipeline**: Secuencia de etapas de procesamiento
- **$match**: Filtrar documentos
- **$group**: Agrupar y calcular
- **$project**: Seleccionar campos
- **$sort**: Ordenar resultados
- **$limit**: Limitar cantidad de resultados

### Índices
- **Índice simple**: En un solo campo
- **Índice compuesto**: En múltiples campos
- **Índice de texto**: Para búsqueda de texto completo
- **Índice TTL**: Para expiración automática

## Pasos para Operaciones Comunes

### 1. Conectar a MongoDB
\`\`\`javascript
const { MongoClient } = require('mongodb');
const client = new MongoClient('mongodb://localhost:27017');
await client.connect();
const db = client.db('mi_proyecto');
\`\`\`

### 2. Insertar Documentos
\`\`\`javascript
// Insertar uno
await collection.insertOne({ nombre: 'Juan', edad: 30 });

// Insertar varios
await collection.insertMany([
  { nombre: 'Ana', edad: 25 },
  { nombre: 'Carlos', edad: 35 }
]);
\`\`\`

### 3. Consultar Documentos
\`\`\`javascript
// Encontrar todos
const todos = await collection.find({}).toArray();

// Encontrar con filtro
const adultos = await collection.find({ edad: { $gte: 18 } }).toArray();

// Encontrar uno
const usuario = await collection.findOne({ nombre: 'Juan' });
\`\`\`

### 4. Actualizar Documentos
\`\`\`javascript
// Actualizar uno
await collection.updateOne(
  { nombre: 'Juan' },
  { $set: { edad: 31 } }
);

// Actualizar varios
await collection.updateMany(
  { edad: { $lt: 18 } },
  { $set: { categoria: 'menor' } }
);
\`\`\`

### 5. Eliminar Documentos
\`\`\`javascript
// Eliminar uno
await collection.deleteOne({ nombre: 'Juan' });

// Eliminar varios
await collection.deleteMany({ edad: { $lt: 18 } });
\`\`\`

### 6. Crear Índices
\`\`\`javascript
// Índice simple
await collection.createIndex({ nombre: 1 });

// Índice compuesto
await collection.createIndex({ nombre: 1, edad: -1 });

// Índice de texto
await collection.createIndex({ descripcion: 'text' });
\`\`\`

### 7. Pipeline de Agregación
\`\`\`javascript
const resultado = await collection.aggregate([
  { $match: { edad: { $gte: 18 } } },
  { $group: { _id: '$categoria', total: { $sum: 1 } } },
  { $sort: { total: -1 } }
]).toArray();
\`\`\`

## Mejores Prácticas

### Diseño de Esquemas
- Embeber documentos relacionados cuando sea apropiado
- Usar referencias para datos que cambian frecuentemente
- Considerar patrones de consulta al diseñar

### Optimización
- Crear índices en campos consultados frecuentemente
- Usar proyección para limitar campos retornados
- Implementar paginación para grandes conjuntos de datos

### Seguridad
- Usar autenticación y autorización
- Validar datos de entrada
- Implementar roles y permisos granulares
