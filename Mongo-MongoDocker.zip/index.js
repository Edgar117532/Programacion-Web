const { MongoClient } = require("mongodb")
require("dotenv").config()

const insertDocuments = require("./queries/01_insert_documents")
const findExamples = require("./queries/02_find_examples")
const updateDeleteExamples = require("./queries/03_update_delete")
const aggregationExamples = require("./queries/04_aggregation")
const indexAndExplainExamples = require("./queries/05_create_index_and_explain")

async function runAllExamples() {
  console.log("🚀 Iniciando ejemplos de MongoDB...\n")

  try {
    // Ejecutar todos los ejemplos en secuencia
    console.log("📝 Ejecutando inserción de documentos...")
    await insertDocuments()

    console.log("\n🔍 Ejecutando ejemplos de consultas...")
    await findExamples()

    console.log("\n✏️ Ejecutando ejemplos de actualización y eliminación...")
    await updateDeleteExamples()

    console.log("\n📊 Ejecutando ejemplos de agregación...")
    await aggregationExamples()

    console.log("\n🗂️ Ejecutando ejemplos de índices y explain...")
    await indexAndExplainExamples()

    console.log("\n✅ Todos los ejemplos ejecutados exitosamente!")
  } catch (error) {
    console.error("❌ Error ejecutando ejemplos:", error)
    process.exit(1)
  }
}

// Función para verificar conexión
async function testConnection() {
  const uri = process.env.MONGODB_URI || "mongodb://localhost:27017"
  const client = new MongoClient(uri)

  try {
    await client.connect()
    console.log("✅ Conexión a MongoDB exitosa")

    const admin = client.db().admin()
    const status = await admin.serverStatus()
    console.log(`📊 MongoDB versión: ${status.version}`)

    return true
  } catch (error) {
    console.error("❌ Error conectando a MongoDB:", error.message)
    return false
  } finally {
    await client.close()
  }
}

// Función principal
async function main() {
  console.log("🔧 Mi Proyecto MongoDB - Ejemplos Prácticos\n")

  // Verificar conexión primero
  const connected = await testConnection()
  if (!connected) {
    console.log("\n💡 Asegúrate de que MongoDB esté ejecutándose:")
    console.log("   - Localmente: mongod")
    console.log("   - Docker: docker-compose up -d")
    process.exit(1)
  }

  // Ejecutar ejemplos
  await runAllExamples()

  console.log("\n📚 Para más información, revisa:")
  console.log("   - teoria/respuestas.md - Conceptos y teoría")
  console.log("   - queries/ - Scripts individuales")
  console.log("   - colecciones/ - Definiciones de vistas")
  console.log("   - README.md - Documentación completa")
}

// Ejecutar si es el archivo principal
if (require.main === module) {
  main().catch(console.error)
}

module.exports = {
  runAllExamples,
  testConnection,
}
