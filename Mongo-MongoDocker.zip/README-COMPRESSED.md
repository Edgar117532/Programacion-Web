# 📝 Todo App - Proyecto MongoDB Comprimido

Una aplicación web simple de lista de tareas usando Node.js, Express, MongoDB y Pug.

## 🚀 Inicio Rápido

### Con Docker (Recomendado)
\`\`\`bash
# Clonar y entrar al directorio
git clone <tu-repo>
cd mi-proyecto-comprimido

# Levantar con Docker
docker-compose -f docker-compose-compressed.yml up --build

# Poblar datos de prueba
docker exec todo-app npm run seed
\`\`\`

### Manual
\`\`\`bash
# Instalar dependencias
npm install

# Iniciar MongoDB localmente
mongod

# Poblar datos de prueba
npm run seed

# Iniciar aplicación
npm run dev
\`\`\`

## 📱 Uso

1. **Abrir**: http://localhost:3000
2. **Agregar tareas**: Escribir en el campo y presionar "Agregar"
3. **Completar**: Hacer clic en "Completar" para marcar como hecha
4. **Eliminar**: Hacer clic en "Eliminar" para borrar la tarea

## 🏗️ Arquitectura

\`\`\`
mi-proyecto-comprimido/
├── app.js                 # Servidor principal con rutas integradas
├── views/index.pug        # Vista única con interfaz completa
├── public/styles.css      # Estilos responsivos
├── seed-data.js          # Script para datos de prueba
├── docker-compose-compressed.yml
├── Dockerfile-compressed
└── package-compressed.json
\`\`\`

## 🔧 Características

- ✅ **CRUD completo** - Crear, leer, actualizar, eliminar tareas
- 📱 **Responsive** - Funciona en móvil y desktop
- 🐳 **Docker ready** - Listo para contenedores
- 🎨 **UI moderna** - Interfaz limpia y atractiva
- ⚡ **Optimizado** - Código mínimo y eficiente

## 🛠️ Tecnologías

- **Backend**: Node.js + Express
- **Base de datos**: MongoDB + Mongoose
- **Frontend**: Pug + CSS3
- **Contenedores**: Docker + Docker Compose

## 📊 Comparación con Versión Original

| Aspecto | Original | Comprimido |
|---------|----------|------------|
| Archivos | 8 archivos | 4 archivos principales |
| Líneas de código | ~150 | ~100 |
| Funcionalidades | Básicas | CRUD completo |
| UI/UX | Simple | Moderna y responsive |
| Docker | Básico | Optimizado |

Esta versión comprimida mantiene toda la funcionalidad esencial mientras reduce la complejidad y mejora la experiencia de usuario.
