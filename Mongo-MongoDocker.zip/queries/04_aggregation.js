const { MongoClient } = require("mongodb")

async function aggregationExamples() {
  const client = new MongoClient("mongodb://localhost:27017")

  try {
    await client.connect()
    console.log("Conectado a MongoDB")

    const db = client.db("mi_proyecto")
    const clientes = db.collection("clientes")
    const productos = db.collection("productos")
    const ordenes = db.collection("ordenes")

    console.log("\n=== EJEMPLOS DE AGREGACIÓN ===\n")

    // 1. Agregación básica - $match y $group
    console.log("1. Contar clientes por estado (activo/inactivo):")
    const clientesPorEstado = await clientes
      .aggregate([
        {
          $group: {
            _id: "$activo",
            total: { $sum: 1 },
            edadPromedio: { $avg: "$edad" },
          },
        },
      ])
      .toArray()

    clientesPorEstado.forEach((grupo) => {
      console.log(`- Activo ${grupo._id}: ${grupo.total} clientes, edad promedio: ${grupo.edadPromedio.toFixed(1)}`)
    })

    // 2. Agregación con $match para filtrar
    console.log("\n2. Productos por categoría (solo activos):")
    const productosPorCategoria = await productos
      .aggregate([
        { $match: { activo: true } },
        {
          $group: {
            _id: "$categoria",
            total: { $sum: 1 },
            precioPromedio: { $avg: "$precio" },
            stockTotal: { $sum: "$stock" },
          },
        },
        { $sort: { total: -1 } },
      ])
      .toArray()

    productosPorCategoria.forEach((categoria) => {
      console.log(
        `- ${categoria._id}: ${categoria.total} productos, precio promedio: $${categoria.precioPromedio.toFixed(2)}, stock total: ${categoria.stockTotal}`,
      )
    })

    // 3. Agregación con $project para seleccionar campos
    console.log("\n3. Información resumida de clientes:")
    const resumenClientes = await clientes
      .aggregate([
        {
          $project: {
            nombre: 1,
            email: 1,
            ciudad: "$direccion.ciudad",
            esAdulto: { $gte: ["$edad", 18] },
            añosDesdeRegistro: {
              $divide: [{ $subtract: [new Date(), "$fecha_registro"] }, 1000 * 60 * 60 * 24 * 365],
            },
          },
        },
      ])
      .toArray()

    resumenClientes.forEach((cliente) => {
      console.log(
        `- ${cliente.nombre} (${cliente.ciudad}) - Adulto: ${cliente.esAdulto}, Años desde registro: ${cliente.añosDesdeRegistro.toFixed(1)}`,
      )
    })

    // 4. Agregación con $lookup (JOIN)
    console.log("\n4. Órdenes con información del cliente:")
    const ordenesConCliente = await ordenes
      .aggregate([
        {
          $lookup: {
            from: "clientes",
            localField: "cliente_id",
            foreignField: "_id",
            as: "cliente_info",
          },
        },
        {
          $unwind: "$cliente_info",
        },
        {
          $project: {
            fecha_orden: 1,
            estado: 1,
            total: 1,
            cliente_nombre: "$cliente_info.nombre",
            cliente_email: "$cliente_info.email",
          },
        },
      ])
      .toArray()

    ordenesConCliente.forEach((orden) => {
      console.log(
        `- Orden ${orden._id}: ${orden.cliente_nombre} (${orden.cliente_email}) - $${orden.total} - ${orden.estado}`,
      )
    })

    // 5. Agregación con $unwind para arrays
    console.log("\n5. Análisis de items de órdenes:")
    const analisisItems = await ordenes
      .aggregate([
        { $unwind: "$items" },
        {
          $group: {
            _id: "$items.producto_id",
            totalVendido: { $sum: "$items.cantidad" },
            ingresoTotal: { $sum: { $multiply: ["$items.cantidad", "$items.precio_unitario"] } },
            ordenesCount: { $sum: 1 },
          },
        },
        { $sort: { totalVendido: -1 } },
      ])
      .toArray()

    console.log("Items más vendidos:")
    analisisItems.forEach((item) => {
      console.log(
        `- Producto ID ${item._id}: ${item.totalVendido} unidades, $${item.ingresoTotal.toFixed(2)} ingresos, ${item.ordenesCount} órdenes`,
      )
    })

    // 6. Agregación con múltiples $lookup
    console.log("\n6. Análisis completo de órdenes con productos:")
    const analisisCompleto = await ordenes
      .aggregate([
        { $unwind: "$items" },
        {
          $lookup: {
            from: "productos",
            localField: "items.producto_id",
            foreignField: "_id",
            as: "producto_info",
          },
        },
        {
          $lookup: {
            from: "clientes",
            localField: "cliente_id",
            foreignField: "_id",
            as: "cliente_info",
          },
        },
        { $unwind: "$producto_info" },
        { $unwind: "$cliente_info" },
        {
          $project: {
            cliente_nombre: "$cliente_info.nombre",
            producto_nombre: "$producto_info.nombre",
            cantidad: "$items.cantidad",
            precio_unitario: "$items.precio_unitario",
            subtotal: { $multiply: ["$items.cantidad", "$items.precio_unitario"] },
            fecha_orden: 1,
            estado: 1,
          },
        },
      ])
      .toArray()

    console.log("Detalle completo de órdenes:")
    analisisCompleto.forEach((detalle) => {
      console.log(
        `- ${detalle.cliente_nombre} compró ${detalle.cantidad}x ${detalle.producto_nombre} por $${detalle.subtotal.toFixed(2)}`,
      )
    })

    // 7. Agregación con $facet (múltiples pipelines)
    console.log("\n7. Estadísticas múltiples de productos:")
    const estadisticasProductos = await productos
      .aggregate([
        {
          $facet: {
            porCategoria: [{ $group: { _id: "$categoria", total: { $sum: 1 } } }, { $sort: { total: -1 } }],
            porRangoPrecio: [
              {
                $bucket: {
                  groupBy: "$precio",
                  boundaries: [0, 50, 200, 500, 2000],
                  default: "Muy caro",
                  output: {
                    total: { $sum: 1 },
                    precioPromedio: { $avg: "$precio" },
                  },
                },
              },
            ],
            estadisticasGenerales: [
              {
                $group: {
                  _id: null,
                  totalProductos: { $sum: 1 },
                  precioPromedio: { $avg: "$precio" },
                  stockTotal: { $sum: "$stock" },
                  precioMinimo: { $min: "$precio" },
                  precioMaximo: { $max: "$precio" },
                },
              },
            ],
          },
        },
      ])
      .toArray()

    const stats = estadisticasProductos[0]

    console.log("Por categoría:")
    stats.porCategoria.forEach((cat) => {
      console.log(`  - ${cat._id}: ${cat.total} productos`)
    })

    console.log("Por rango de precio:")
    stats.porRangoPrecio.forEach((rango) => {
      console.log(`  - $${rango._id}: ${rango.total} productos, promedio: $${rango.precioPromedio.toFixed(2)}`)
    })

    console.log("Estadísticas generales:")
    const general = stats.estadisticasGenerales[0]
    console.log(`  - Total productos: ${general.totalProductos}`)
    console.log(`  - Precio promedio: $${general.precioPromedio.toFixed(2)}`)
    console.log(`  - Stock total: ${general.stockTotal}`)
    console.log(`  - Rango de precios: $${general.precioMinimo} - $${general.precioMaximo}`)

    // 8. Agregación con $addFields y operaciones de fecha
    console.log("\n8. Análisis temporal de clientes:")
    const analisisTemporal = await clientes
      .aggregate([
        {
          $addFields: {
            mesRegistro: { $month: "$fecha_registro" },
            añoRegistro: { $year: "$fecha_registro" },
            diasDesdeRegistro: {
              $divide: [{ $subtract: [new Date(), "$fecha_registro"] }, 1000 * 60 * 60 * 24],
            },
          },
        },
        {
          $group: {
            _id: {
              año: "$añoRegistro",
              mes: "$mesRegistro",
            },
            totalClientes: { $sum: 1 },
            edadPromedio: { $avg: "$edad" },
            diasPromedioDesdeRegistro: { $avg: "$diasDesdeRegistro" },
          },
        },
        { $sort: { "_id.año": 1, "_id.mes": 1 } },
      ])
      .toArray()

    console.log("Registros por mes:")
    analisisTemporal.forEach((periodo) => {
      console.log(
        `  - ${periodo._id.año}/${periodo._id.mes}: ${periodo.totalClientes} clientes, edad promedio: ${periodo.edadPromedio.toFixed(1)}, días desde registro: ${periodo.diasPromedioDesdeRegistro.toFixed(0)}`,
      )
    })

    // 9. Agregación con $sample (muestra aleatoria)
    console.log("\n9. Muestra aleatoria de 2 productos:")
    const muestraProductos = await productos
      .aggregate([{ $sample: { size: 2 } }, { $project: { nombre: 1, precio: 1, categoria: 1 } }])
      .toArray()

    muestraProductos.forEach((producto) => {
      console.log(`  - ${producto.nombre} ($${producto.precio}) - ${producto.categoria}`)
    })

    // 10. Pipeline complejo con múltiples etapas
    console.log("\n10. Análisis de rentabilidad por cliente:")
    const rentabilidadClientes = await ordenes
      .aggregate([
        // Expandir items
        { $unwind: "$items" },

        // Calcular subtotal por item
        {
          $addFields: {
            subtotal: { $multiply: ["$items.cantidad", "$items.precio_unitario"] },
          },
        },

        // Agrupar por cliente
        {
          $group: {
            _id: "$cliente_id",
            totalOrdenes: { $sum: 1 },
            totalGastado: { $sum: "$subtotal" },
            promedioOrden: { $avg: "$subtotal" },
            primeraCompra: { $min: "$fecha_orden" },
            ultimaCompra: { $max: "$fecha_orden" },
          },
        },

        // Agregar información del cliente
        {
          $lookup: {
            from: "clientes",
            localField: "_id",
            foreignField: "_id",
            as: "cliente_info",
          },
        },

        { $unwind: "$cliente_info" },

        // Calcular métricas adicionales
        {
          $addFields: {
            diasEntrePrimeroYUltimo: {
              $divide: [{ $subtract: ["$ultimaCompra", "$primeraCompra"] }, 1000 * 60 * 60 * 24],
            },
          },
        },

        // Proyectar resultado final
        {
          $project: {
            nombre: "$cliente_info.nombre",
            email: "$cliente_info.email",
            totalOrdenes: 1,
            totalGastado: { $round: ["$totalGastado", 2] },
            promedioOrden: { $round: ["$promedioOrden", 2] },
            diasEntrePrimeroYUltimo: { $round: ["$diasEntrePrimeroYUltimo", 0] },
          },
        },

        // Ordenar por total gastado
        { $sort: { totalGastado: -1 } },
      ])
      .toArray()

    console.log("Rentabilidad por cliente:")
    rentabilidadClientes.forEach((cliente) => {
      console.log(
        `  - ${cliente.nombre}: $${cliente.totalGastado} en ${cliente.totalOrdenes} órdenes (promedio: $${cliente.promedioOrden})`,
      )
    })

    console.log("\n=== FIN DE EJEMPLOS DE AGREGACIÓN ===")
  } catch (error) {
    console.error("Error:", error)
  } finally {
    await client.close()
  }
}

// Ejecutar si es llamado directamente
if (require.main === module) {
  aggregationExamples()
}

module.exports = aggregationExamples
