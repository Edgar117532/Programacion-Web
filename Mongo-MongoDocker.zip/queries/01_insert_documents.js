const { MongoClient } = require("mongodb")

async function insertDocuments() {
  const client = new MongoClient("mongodb://localhost:27017")

  try {
    await client.connect()
    console.log("Conectado a MongoDB")

    const db = client.db("mi_proyecto")
    const clientes = db.collection("clientes")
    const productos = db.collection("productos")
    const ordenes = db.collection("ordenes")

    // Limpiar colecciones existentes
    await clientes.deleteMany({})
    await productos.deleteMany({})
    await ordenes.deleteMany({})

    console.log("Colecciones limpiadas")

    // Insertar clientes
    const clientesData = [
      {
        nombre: "Juan Pérez",
        email: "juan@email.com",
        edad: 30,
        activo: true,
        direccion: {
          calle: "Av. Principal 123",
          ciudad: "Madrid",
          codigo_postal: "28001",
        },
        telefono: "+34 600 123 456",
        fecha_registro: new Date("2023-01-15"),
      },
      {
        nombre: "María García",
        email: "maria@email.com",
        edad: 25,
        activo: true,
        direccion: {
          calle: "Calle Secundaria 456",
          ciudad: "Barcelona",
          codigo_postal: "08001",
        },
        telefono: "+34 600 789 012",
        fecha_registro: new Date("2023-02-20"),
      },
      {
        nombre: "Carlos López",
        email: "carlos@email.com",
        edad: 35,
        activo: false,
        direccion: {
          calle: "Plaza Mayor 789",
          ciudad: "Valencia",
          codigo_postal: "46001",
        },
        telefono: "+34 600 345 678",
        fecha_registro: new Date("2023-03-10"),
      },
    ]

    const resultClientes = await clientes.insertMany(clientesData)
    console.log(`${resultClientes.insertedCount} clientes insertados`)

    // Insertar productos
    const productosData = [
      {
        nombre: "Laptop Gaming",
        precio: 1299.99,
        categoria: "Electrónicos",
        stock: 15,
        descripcion: "Laptop para gaming de alta gama",
        especificaciones: {
          procesador: "Intel i7",
          ram: "16GB",
          almacenamiento: "1TB SSD",
        },
        activo: true,
      },
      {
        nombre: "Mouse Inalámbrico",
        precio: 29.99,
        categoria: "Accesorios",
        stock: 50,
        descripcion: "Mouse inalámbrico ergonómico",
        especificaciones: {
          conectividad: "Bluetooth",
          bateria: "6 meses",
          dpi: "1600",
        },
        activo: true,
      },
      {
        nombre: "Monitor 4K",
        precio: 399.99,
        categoria: "Electrónicos",
        stock: 8,
        descripcion: "Monitor 4K de 27 pulgadas",
        especificaciones: {
          resolucion: "3840x2160",
          tamaño: '27"',
          panel: "IPS",
        },
        activo: true,
      },
    ]

    const resultProductos = await productos.insertMany(productosData)
    console.log(`${resultProductos.insertedCount} productos insertados`)

    // Obtener IDs para las órdenes
    const clienteIds = Object.values(resultClientes.insertedIds)
    const productoIds = Object.values(resultProductos.insertedIds)

    // Insertar órdenes
    const ordenesData = [
      {
        cliente_id: clienteIds[0],
        fecha_orden: new Date("2023-04-01"),
        estado: "completada",
        items: [
          {
            producto_id: productoIds[0],
            cantidad: 1,
            precio_unitario: 1299.99,
          },
          {
            producto_id: productoIds[1],
            cantidad: 2,
            precio_unitario: 29.99,
          },
        ],
        total: 1359.97,
        direccion_envio: {
          calle: "Av. Principal 123",
          ciudad: "Madrid",
          codigo_postal: "28001",
        },
      },
      {
        cliente_id: clienteIds[1],
        fecha_orden: new Date("2023-04-05"),
        estado: "pendiente",
        items: [
          {
            producto_id: productoIds[2],
            cantidad: 1,
            precio_unitario: 399.99,
          },
        ],
        total: 399.99,
        direccion_envio: {
          calle: "Calle Secundaria 456",
          ciudad: "Barcelona",
          codigo_postal: "08001",
        },
      },
    ]

    const resultOrdenes = await ordenes.insertMany(ordenesData)
    console.log(`${resultOrdenes.insertedCount} órdenes insertadas`)

    console.log("Todos los documentos insertados exitosamente")
  } catch (error) {
    console.error("Error:", error)
  } finally {
    await client.close()
  }
}

// Ejecutar si es llamado directamente
if (require.main === module) {
  insertDocuments()
}

module.exports = insertDocuments
