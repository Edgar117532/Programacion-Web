const { MongoClient } = require("mongodb")

async function findExamples() {
  const client = new MongoClient("mongodb://localhost:27017")

  try {
    await client.connect()
    console.log("Conectado a MongoDB")

    const db = client.db("mi_proyecto")
    const clientes = db.collection("clientes")
    const productos = db.collection("productos")
    const ordenes = db.collection("ordenes")

    console.log("\n=== EJEMPLOS DE CONSULTAS FIND ===\n")

    // 1. Encontrar todos los documentos
    console.log("1. Todos los clientes:")
    const todosClientes = await clientes.find({}).toArray()
    console.log(`Encontrados ${todosClientes.length} clientes`)
    todosClientes.forEach((cliente) => {
      console.log(`- ${cliente.nombre} (${cliente.email})`)
    })

    // 2. Consulta con filtro simple
    console.log("\n2. Clientes activos:")
    const clientesActivos = await clientes.find({ activo: true }).toArray()
    clientesActivos.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Activo: ${cliente.activo}`)
    })

    // 3. Consulta con operadores de comparación
    console.log("\n3. Clientes mayores de 30 años:")
    const clientesMayores = await clientes.find({ edad: { $gte: 30 } }).toArray()
    clientesMayores.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Edad: ${cliente.edad}`)
    })

    // 4. Consulta con múltiples condiciones (AND implícito)
    console.log("\n4. Clientes activos mayores de 25 años:")
    const clientesActivosMayores = await clientes
      .find({
        activo: true,
        edad: { $gt: 25 },
      })
      .toArray()
    clientesActivosMayores.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Edad: ${cliente.edad}, Activo: ${cliente.activo}`)
    })

    // 5. Consulta con operador OR
    console.log("\n5. Clientes de Madrid o Barcelona:")
    const clientesCiudades = await clientes
      .find({
        $or: [{ "direccion.ciudad": "Madrid" }, { "direccion.ciudad": "Barcelona" }],
      })
      .toArray()
    clientesCiudades.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Ciudad: ${cliente.direccion.ciudad}`)
    })

    // 6. Consulta en campos anidados
    console.log("\n6. Clientes de Madrid:")
    const clientesMadrid = await clientes.find({ "direccion.ciudad": "Madrid" }).toArray()
    clientesMadrid.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - ${cliente.direccion.calle}`)
    })

    // 7. Consulta con expresiones regulares
    console.log('\n7. Clientes cuyo nombre contiene "Juan":')
    const clientesJuan = await clientes
      .find({
        nombre: { $regex: /Juan/i },
      })
      .toArray()
    clientesJuan.forEach((cliente) => {
      console.log(`- ${cliente.nombre}`)
    })

    // 8. Consulta con proyección (seleccionar campos específicos)
    console.log("\n8. Solo nombres y emails de clientes:")
    const nombresEmails = await clientes
      .find(
        {},
        {
          projection: { nombre: 1, email: 1, _id: 0 },
        },
      )
      .toArray()
    nombresEmails.forEach((cliente) => {
      console.log(`- ${cliente.nombre}: ${cliente.email}`)
    })

    // 9. Consulta con ordenamiento
    console.log("\n9. Clientes ordenados por edad (descendente):")
    const clientesOrdenados = await clientes.find({}).sort({ edad: -1 }).toArray()
    clientesOrdenados.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Edad: ${cliente.edad}`)
    })

    // 10. Consulta con límite
    console.log("\n10. Primeros 2 clientes:")
    const primerosDos = await clientes.find({}).limit(2).toArray()
    primerosDos.forEach((cliente) => {
      console.log(`- ${cliente.nombre}`)
    })

    // 11. Consulta con skip y limit (paginación)
    console.log("\n11. Paginación - página 2 (1 elemento por página):")
    const pagina2 = await clientes.find({}).skip(1).limit(1).toArray()
    pagina2.forEach((cliente) => {
      console.log(`- ${cliente.nombre}`)
    })

    // 12. Contar documentos
    console.log("\n12. Conteos:")
    const totalClientes = await clientes.countDocuments()
    const clientesActivosCount = await clientes.countDocuments({ activo: true })
    console.log(`- Total clientes: ${totalClientes}`)
    console.log(`- Clientes activos: ${clientesActivosCount}`)

    // 13. Consulta con operador IN
    console.log("\n13. Productos de categorías específicas:")
    const productosEspecificos = await productos
      .find({
        categoria: { $in: ["Electrónicos", "Accesorios"] },
      })
      .toArray()
    productosEspecificos.forEach((producto) => {
      console.log(`- ${producto.nombre} - Categoría: ${producto.categoria}`)
    })

    // 14. Consulta con rangos de fechas
    console.log("\n14. Clientes registrados en 2023:")
    const clientesRegistrados2023 = await clientes
      .find({
        fecha_registro: {
          $gte: new Date("2023-01-01"),
          $lt: new Date("2024-01-01"),
        },
      })
      .toArray()
    clientesRegistrados2023.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Registro: ${cliente.fecha_registro.toDateString()}`)
    })

    // 15. Consulta con exists
    console.log("\n15. Documentos que tienen campo teléfono:")
    const conTelefono = await clientes.find({ telefono: { $exists: true } }).toArray()
    conTelefono.forEach((cliente) => {
      console.log(`- ${cliente.nombre} - Teléfono: ${cliente.telefono}`)
    })

    console.log("\n=== FIN DE EJEMPLOS ===")
  } catch (error) {
    console.error("Error:", error)
  } finally {
    await client.close()
  }
}

// Ejecutar si es llamado directamente
if (require.main === module) {
  findExamples()
}

module.exports = findExamples
