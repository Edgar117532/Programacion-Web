const { MongoClient } = require("mongodb")

async function indexAndExplainExamples() {
  const client = new MongoClient("mongodb://localhost:27017")

  try {
    await client.connect()
    console.log("Conectado a MongoDB")

    const db = client.db("mi_proyecto")
    const clientes = db.collection("clientes")
    const productos = db.collection("productos")
    const ordenes = db.collection("ordenes")

    console.log("\n=== EJEMPLOS DE ÍNDICES Y EXPLAIN ===\n")

    // 1. Listar índices existentes
    console.log("1. Índices existentes en la colección clientes:")
    const indicesExistentes = await clientes.listIndexes().toArray()
    indicesExistentes.forEach((indice) => {
      console.log(`- ${indice.name}: ${JSON.stringify(indice.key)}`)
    })

    // 2. Crear índice simple
    console.log("\n2. Creando índice simple en el campo email:")
    await clientes.createIndex({ email: 1 })
    console.log("Índice creado en email")

    // 3. Crear índice compuesto
    console.log("\n3. Creando índice compuesto en activo y edad:")
    await clientes.createIndex({ activo: 1, edad: -1 })
    console.log("Índice compuesto creado en activo (asc) y edad (desc)")

    // 4. Crear índice en campo anidado
    console.log("\n4. Creando índice en campo anidado (direccion.ciudad):")
    await clientes.createIndex({ "direccion.ciudad": 1 })
    console.log("Índice creado en direccion.ciudad")

    // 5. Crear índice de texto para búsqueda
    console.log("\n5. Creando índice de texto en productos:")
    await productos.createIndex(
      {
        nombre: "text",
        detalle: "text",
      },
      {
        weights: { nombre: 10, detalle: 5 },
        name: "texto_productos",
      },
    )
    console.log("Índice de texto creado en nombre y detalle")

    // 6. Crear índice TTL (Time To Live)
    console.log("\n6. Creando colección temporal con índice TTL:")
    const sesiones = db.collection("sesiones")
    await sesiones.createIndex(
      {
        fechaExpiracion: 1,
      },
      {
        expireAfterSeconds: 3600, // 1 hora
      },
    )
    console.log("Índice TTL creado (expira en 1 hora)")

    // Insertar documento de prueba para TTL
    await sesiones.insertOne({
      usuario: "test",
      fechaExpiracion: new Date(),
    })

    // 7. Crear índice único
    console.log("\n7. Creando índice único en email:")
    try {
      await clientes.createIndex({ email: 1 }, { unique: true })
      console.log("Índice único creado en email")
    } catch (error) {
      console.log("El índice único ya existe o hay duplicados")
    }

    // 8. Crear índice parcial
    console.log("\n8. Creando índice parcial (solo clientes activos):")
    await clientes.createIndex(
      { nombre: 1 },
      {
        partialFilterExpression: { activo: true },
        name: "nombre_clientes_activos",
      },
    )
    console.log("Índice parcial creado para clientes activos")

    // 9. Crear índice sparse
    console.log("\n9. Creando índice sparse en teléfono:")
    await clientes.createIndex({ telefono: 1 }, { sparse: true })
    console.log("Índice sparse creado en teléfono")

    // 10. Listar todos los índices después de crearlos
    console.log("\n10. Todos los índices en clientes después de crear:")
    const todosLosIndices = await clientes.listIndexes().toArray()
    todosLosIndices.forEach((indice) => {
      console.log(
        `- ${indice.name}: ${JSON.stringify(indice.key)} ${indice.unique ? "(ÚNICO)" : ""} ${indice.sparse ? "(SPARSE)" : ""}`,
      )
    })

    // === EJEMPLOS DE EXPLAIN ===

    console.log("\n=== ANÁLISIS CON EXPLAIN ===\n")

    // 11. Explain de consulta sin índice
    console.log("11. Explain de consulta por edad (sin índice específico):")
    const explainSinIndice = await clientes.find({ edad: 30 }).explain("executionStats")
    console.log(`- Documentos examinados: ${explainSinIndice.executionStats.totalDocsExamined}`)
    console.log(`- Documentos retornados: ${explainSinIndice.executionStats.totalDocsReturned}`)
    console.log(`- Tiempo de ejecución: ${explainSinIndice.executionStats.executionTimeMillis}ms`)
    console.log(`- Etapa ganadora: ${explainSinIndice.executionStats.executionStages.stage}`)

    // 12. Explain de consulta con índice
    console.log("\n12. Explain de consulta por email (con índice):")
    const explainConIndice = await clientes.find({ email: "juan@email.com" }).explain("executionStats")
    console.log(`- Documentos examinados: ${explainConIndice.executionStats.totalDocsExamined}`)
    console.log(`- Documentos retornados: ${explainConIndice.executionStats.totalDocsReturned}`)
    console.log(`- Tiempo de ejecución: ${explainConIndice.executionStats.executionTimeMillis}ms`)
    console.log(`- Etapa ganadora: ${explainConIndice.executionStats.executionStages.stage}`)
    console.log(`- Índice usado: ${explainConIndice.executionStats.executionStages.indexName || "Ninguno"}`)

    // 13. Explain de consulta compuesta
    console.log("\n13. Explain de consulta compuesta (activo y edad):")
    const explainCompuesto = await clientes.find({ activo: true, edad: { $gte: 25 } }).explain("executionStats")
    console.log(`- Documentos examinados: ${explainCompuesto.executionStats.totalDocsExamined}`)
    console.log(`- Documentos retornados: ${explainCompuesto.executionStats.totalDocsReturned}`)
    console.log(`- Tiempo de ejecución: ${explainCompuesto.executionStats.executionTimeMillis}ms`)
    console.log(`- Etapa ganadora: ${explainCompuesto.executionStats.executionStages.stage}`)
    console.log(`- Índice usado: ${explainCompuesto.executionStats.executionStages.indexName || "Ninguno"}`)

    // 14. Explain de búsqueda de texto
    console.log("\n14. Explain de búsqueda de texto:")
    const explainTexto = await productos.find({ $text: { $search: "laptop gaming" } }).explain("executionStats")
    console.log(`- Documentos examinados: ${explainTexto.executionStats.totalDocsExamined}`)
    console.log(`- Documentos retornados: ${explainTexto.executionStats.totalDocsReturned}`)
    console.log(`- Tiempo de ejecución: ${explainTexto.executionStats.executionTimeMillis}ms`)
    console.log(`- Etapa ganadora: ${explainTexto.executionStats.executionStages.stage}`)

    // 15. Explain de agregación
    console.log("\n15. Explain de pipeline de agregación:")
    const explainAgregacion = await clientes
      .aggregate([{ $match: { activo: true } }, { $group: { _id: "$direccion.ciudad", total: { $sum: 1 } } }])
      .explain("executionStats")

    console.log("Pipeline de agregación:")
    explainAgregacion.stages.forEach((stage, index) => {
      console.log(`- Etapa ${index + 1}: ${stage.stage || "N/A"}`)
      if (stage.executionStats) {
        console.log(`  Documentos examinados: ${stage.executionStats.totalDocsExamined || "N/A"}`)
        console.log(`  Tiempo: ${stage.executionStats.executionTimeMillis || "N/A"}ms`)
      }
    })

    // 16. Estadísticas de índices
    console.log("\n16. Estadísticas de uso de índices:")
    const statsIndices = await clientes.aggregate([{ $indexStats: {} }]).toArray()

    statsIndices.forEach((stat) => {
      console.log(`- Índice: ${stat.name}`)
      console.log(`  Accesos: ${stat.accesses.ops}`)
      console.log(`  Desde: ${stat.accesses.since}`)
    })

    // 17. Hint para forzar uso de índice específico
    console.log("\n17. Usando hint para forzar índice específico:")
    const conHint = await clientes
      .find({ activo: true, edad: 30 })
      .hint({ activo: 1, edad: -1 })
      .explain("executionStats")

    console.log(`- Índice forzado: ${conHint.executionStats.executionStages.indexName}`)
    console.log(`- Documentos examinados: ${conHint.executionStats.totalDocsExamined}`)

    // 18. Análisis de rendimiento comparativo
    console.log("\n18. Comparación de rendimiento:")

    // Sin índice en edad
    const inicioSinIndice = Date.now()
    await clientes.find({ edad: { $gte: 25 } }).toArray()
    const tiempoSinIndice = Date.now() - inicioSinIndice

    // Crear índice en edad
    await clientes.createIndex({ edad: 1 })

    // Con índice en edad
    const inicioConIndice = Date.now()
    await clientes.find({ edad: { $gte: 25 } }).toArray()
    const tiempoConIndice = Date.now() - inicioConIndice

    console.log(`- Sin índice en edad: ${tiempoSinIndice}ms`)
    console.log(`- Con índice en edad: ${tiempoConIndice}ms`)
    console.log(`- Mejora: ${tiempoSinIndice > tiempoConIndice ? "Sí" : "No"}`)

    // 19. Información sobre el tamaño de índices
    console.log("\n19. Estadísticas de la colección:")
    const stats = await clientes.stats()
    console.log(`- Documentos: ${stats.count}`)
    console.log(`- Tamaño promedio documento: ${(stats.avgObjSize || 0).toFixed(2)} bytes`)
    console.log(`- Tamaño total datos: ${(stats.size / 1024).toFixed(2)} KB`)
    console.log(`- Tamaño total índices: ${(stats.totalIndexSize / 1024).toFixed(2)} KB`)
    console.log(`- Número de índices: ${stats.nindexes}`)

    // 20. Eliminar índice (ejemplo)
    console.log("\n20. Eliminando índice de ejemplo:")
    try {
      await clientes.dropIndex("nombre_clientes_activos")
      console.log("Índice parcial eliminado")
    } catch (error) {
      console.log("Error al eliminar índice o no existe")
    }

    console.log("\n=== RECOMENDACIONES DE ÍNDICES ===")
    console.log("1. Crear índices en campos consultados frecuentemente")
    console.log("2. Usar índices compuestos para consultas con múltiples campos")
    console.log("3. Considerar el orden de campos en índices compuestos")
    console.log("4. Usar índices parciales para subconjuntos específicos")
    console.log("5. Monitorear el uso de índices con $indexStats")
    console.log("6. Eliminar índices no utilizados para ahorrar espacio")
    console.log("7. Usar explain() para analizar el rendimiento de consultas")

    console.log("\n=== FIN DE EJEMPLOS DE ÍNDICES ===")
  } catch (error) {
    console.error("Error:", error)
  } finally {
    await client.close()
  }
}

// Ejecutar si es llamado directamente
if (require.main === module) {
  indexAndExplainExamples()
}

module.exports = indexAndExplainExamples
