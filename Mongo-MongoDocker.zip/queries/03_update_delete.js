const { MongoClient } = require("mongodb")

async function updateDeleteExamples() {
  const client = new MongoClient("mongodb://localhost:27017")

  try {
    await client.connect()
    console.log("Conectado a MongoDB")

    const db = client.db("mi_proyecto")
    const clientes = db.collection("clientes")
    const productos = db.collection("productos")

    console.log("\n=== EJEMPLOS DE UPDATE Y DELETE ===\n")

    // 1. updateOne - Actualizar un documento
    console.log("1. Actualizando edad de Juan Pérez:")
    const updateResult1 = await clientes.updateOne({ nombre: "Juan Pérez" }, { $set: { edad: 31 } })
    console.log(`Documentos modificados: ${updateResult1.modifiedCount}`)

    // Verificar el cambio
    const juanActualizado = await clientes.findOne({ nombre: "Juan Pérez" })
    console.log(`Nueva edad de Juan: ${juanActualizado.edad}`)

    // 2. updateMany - Actualizar múltiples documentos
    console.log("\n2. Actualizando todos los clientes activos:")
    const updateResult2 = await clientes.updateMany({ activo: true }, { $set: { ultima_actualizacion: new Date() } })
    console.log(`Documentos modificados: ${updateResult2.modifiedCount}`)

    // 3. Operadores de actualización - $inc (incrementar)
    console.log("\n3. Incrementando stock de productos:")
    const updateResult3 = await productos.updateMany({ categoria: "Accesorios" }, { $inc: { stock: 10 } })
    console.log(`Productos actualizados: ${updateResult3.modifiedCount}`)

    // Verificar el cambio
    const accesorios = await productos.find({ categoria: "Accesorios" }).toArray()
    accesorios.forEach((producto) => {
      console.log(`- ${producto.nombre}: Stock = ${producto.stock}`)
    })

    // 4. Operador $push - Agregar elemento a array
    console.log("\n4. Agregando etiquetas a productos:")
    await productos.updateOne({ nombre: "Laptop Gaming" }, { $push: { etiquetas: "gaming" } })

    await productos.updateOne(
      { nombre: "Laptop Gaming" },
      { $push: { etiquetas: { $each: ["alta-gama", "portatil"] } } },
    )

    const laptopConEtiquetas = await productos.findOne({ nombre: "Laptop Gaming" })
    console.log(`Etiquetas de Laptop Gaming: ${laptopConEtiquetas.etiquetas || "No tiene etiquetas"}`)

    // 5. Operador $pull - Remover elemento de array
    console.log("\n5. Removiendo etiqueta específica:")
    await productos.updateOne({ nombre: "Laptop Gaming" }, { $pull: { etiquetas: "portatil" } })

    const laptopSinPortatil = await productos.findOne({ nombre: "Laptop Gaming" })
    console.log(`Etiquetas después de $pull: ${laptopSinPortatil.etiquetas}`)

    // 6. Operador $addToSet - Agregar sin duplicados
    console.log("\n6. Agregando categorías secundarias sin duplicados:")
    await productos.updateOne(
      { nombre: "Mouse Inalámbrico" },
      { $addToSet: { categorias_secundarias: { $each: ["oficina", "gaming", "oficina"] } } },
    )

    const mouseConCategorias = await productos.findOne({ nombre: "Mouse Inalámbrico" })
    console.log(`Categorías secundarias: ${mouseConCategorias.categorias_secundarias || "No tiene"}`)

    // 7. Operador $unset - Remover campo
    console.log("\n7. Removiendo campo temporal:")
    await clientes.updateMany({}, { $unset: { ultima_actualizacion: "" } })
    console.log("Campo ultima_actualizacion removido de todos los clientes")

    // 8. Operador $rename - Renombrar campo
    console.log("\n8. Renombrando campo descripcion a detalle:")
    await productos.updateMany({}, { $rename: { descripcion: "detalle" } })
    console.log("Campo descripcion renombrado a detalle")

    // 9. Update con upsert (insertar si no existe)
    console.log("\n9. Upsert - Insertar cliente si no existe:")
    const upsertResult = await clientes.updateOne(
      { email: "nuevo@email.com" },
      {
        $set: {
          nombre: "Cliente Nuevo",
          email: "nuevo@email.com",
          edad: 28,
          activo: true,
          fecha_registro: new Date(),
        },
      },
      { upsert: true },
    )
    console.log(`Documento insertado: ${upsertResult.upsertedCount > 0 ? "Sí" : "No"}`)
    console.log(`ID del nuevo documento: ${upsertResult.upsertedId || "N/A"}`)

    // 10. replaceOne - Reemplazar documento completo
    console.log("\n10. Reemplazando documento completo:")
    const replaceResult = await clientes.replaceOne(
      { email: "nuevo@email.com" },
      {
        nombre: "Cliente Reemplazado",
        email: "nuevo@email.com",
        edad: 30,
        activo: false,
        direccion: {
          calle: "Nueva Dirección 123",
          ciudad: "Sevilla",
          codigo_postal: "41001",
        },
        fecha_registro: new Date(),
      },
    )
    console.log(`Documentos reemplazados: ${replaceResult.modifiedCount}`)

    // === OPERACIONES DELETE ===

    console.log("\n=== OPERACIONES DELETE ===\n")

    // 11. deleteOne - Eliminar un documento
    console.log("11. Eliminando un cliente inactivo:")
    const deleteResult1 = await clientes.deleteOne({ activo: false })
    console.log(`Documentos eliminados: ${deleteResult1.deletedCount}`)

    // 12. deleteMany - Eliminar múltiples documentos
    console.log("\n12. Eliminando productos sin stock:")
    // Primero crear algunos productos sin stock para el ejemplo
    await productos.insertMany([
      { nombre: "Producto Sin Stock 1", precio: 10, stock: 0, categoria: "Test" },
      { nombre: "Producto Sin Stock 2", precio: 20, stock: 0, categoria: "Test" },
    ])

    const deleteResult2 = await productos.deleteMany({ stock: 0 })
    console.log(`Productos sin stock eliminados: ${deleteResult2.deletedCount}`)

    // 13. Eliminar con condiciones complejas
    console.log("\n13. Eliminando productos de categoría Test:")
    const deleteResult3 = await productos.deleteMany({ categoria: "Test" })
    console.log(`Productos de prueba eliminados: ${deleteResult3.deletedCount}`)

    // 14. Mostrar estado final
    console.log("\n=== ESTADO FINAL ===")
    const totalClientesFinales = await clientes.countDocuments()
    const totalProductosFinales = await productos.countDocuments()

    console.log(`Total clientes restantes: ${totalClientesFinales}`)
    console.log(`Total productos restantes: ${totalProductosFinales}`)

    // Mostrar algunos documentos finales
    console.log("\nClientes restantes:")
    const clientesFinales = await clientes.find({}).toArray()
    clientesFinales.forEach((cliente) => {
      console.log(`- ${cliente.nombre} (${cliente.email}) - Activo: ${cliente.activo}`)
    })

    console.log("\nProductos restantes:")
    const productosFinales = await productos.find({}).toArray()
    productosFinales.forEach((producto) => {
      console.log(`- ${producto.nombre} - Stock: ${producto.stock} - Precio: $${producto.precio}`)
    })

    console.log("\n=== FIN DE EJEMPLOS UPDATE/DELETE ===")
  } catch (error) {
    console.error("Error:", error)
  } finally {
    await client.close()
  }
}

// Ejecutar si es llamado directamente
if (require.main === module) {
  updateDeleteExamples()
}

module.exports = updateDeleteExamples
