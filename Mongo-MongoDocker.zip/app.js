const express = require("express")
const mongoose = require("mongoose")
const path = require("path")

const app = express()
const PORT = process.env.PORT || 3000

mongoose
  .connect(process.env.MONGODB_URI || "mongodb://mongodb:27017/todos", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("✅ MongoDB conectado"))
  .catch((err) => console.error("❌ Error MongoDB:", err))

const todoSchema = new mongoose.Schema({
  description: { type: String, required: true },
  complete: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
})

const Todo = mongoose.model("Todo", todoSchema)

// Configuración
app.set("views", path.join(__dirname, "views"))
app.set("view engine", "pug")
app.use(express.static(path.join(__dirname, "public")))
app.use(express.urlencoded({ extended: true }))

app.get("/", async (req, res) => {
  try {
    const todos = await Todo.find().sort({ createdAt: -1 })
    res.render("index", { title: "Lista de Tareas", todos })
  } catch (error) {
    res.status(500).render("error", { error: "Error al cargar tareas" })
  }
})

app.post("/add", async (req, res) => {
  try {
    await Todo.create({ description: req.body.description })
    res.redirect("/")
  } catch (error) {
    res.status(500).redirect("/")
  }
})

app.post("/toggle/:id", async (req, res) => {
  try {
    const todo = await Todo.findById(req.params.id)
    todo.complete = !todo.complete
    await todo.save()
    res.redirect("/")
  } catch (error) {
    res.status(500).redirect("/")
  }
})

app.delete("/delete/:id", async (req, res) => {
  try {
    await Todo.findByIdAndDelete(req.params.id)
    res.json({ success: true })
  } catch (error) {
    res.status(500).json({ error: "Error al eliminar" })
  }
})

app.listen(PORT, () => {
  console.log(`🚀 Servidor en http://localhost:${PORT}`)
})
