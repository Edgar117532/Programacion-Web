#!/usr/bin/env node

/**
 * Script de configuración inicial de la base de datos MongoDB
 * Crea las bases de datos, colecciones e índices necesarios
 */

require("dotenv").config()
const { MongoClient } = require("mongodb")

// Configuración de conexión
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://admin:password123@localhost:27017"
const DB_NAME = process.env.DB_NAME || "mi_proyecto_mongo"

async function setupDatabase() {
  let client

  try {
    console.log("🚀 Iniciando configuración de la base de datos...")

    // Conectar a MongoDB
    client = new MongoClient(MONGODB_URI)
    await client.connect()
    console.log("✅ Conectado a MongoDB")

    const db = client.db(DB_NAME)

    // Crear colecciones si no existen
    const collections = ["clientes", "productos", "ordenes"]

    for (const collectionName of collections) {
      try {
        await db.createCollection(collectionName)
        console.log(`✅ Colección '${collectionName}' creada`)
      } catch (error) {
        if (error.code === 48) {
          console.log(`ℹ️  Colección '${collectionName}' ya existe`)
        } else {
          throw error
        }
      }
    }

    // Crear índices básicos
    console.log("📊 Creando índices...")

    // Índices para clientes
    await db.collection("clientes").createIndex({ email: 1 }, { unique: true })
    await db.collection("clientes").createIndex({ activo: 1 })
    await db.collection("clientes").createIndex({ "direccion.ciudad": 1 })

    // Índices para productos
    await db.collection("productos").createIndex({ categoria: 1 })
    await db.collection("productos").createIndex({ precio: 1 })
    await db.collection("productos").createIndex({ stock: 1 })

    // Índices para órdenes
    await db.collection("ordenes").createIndex({ cliente_id: 1 })
    await db.collection("ordenes").createIndex({ fecha_orden: -1 })
    await db.collection("ordenes").createIndex({ estado: 1 })
    await db.collection("ordenes").createIndex({ total: -1 })

    console.log("✅ Índices creados correctamente")

    // Verificar conexión y mostrar estadísticas
    const stats = await db.stats()
    console.log(`📈 Base de datos '${DB_NAME}' configurada correctamente`)
    console.log(`   - Colecciones: ${stats.collections}`)
    console.log(`   - Tamaño: ${(stats.dataSize / 1024).toFixed(2)} KB`)

    console.log("\n🎉 ¡Configuración completada exitosamente!")
    console.log("\n📝 Próximos pasos:")
    console.log("   1. npm run seed     - Cargar datos de ejemplo")
    console.log("   2. npm run queries  - Ejecutar consultas de ejemplo")
  } catch (error) {
    console.error("❌ Error durante la configuración:", error.message)
    process.exit(1)
  } finally {
    if (client) {
      await client.close()
      console.log("🔌 Conexión cerrada")
    }
  }
}

// Ejecutar si se llama directamente
if (require.main === module) {
  setupDatabase()
}

module.exports = { setupDatabase }
