#!/usr/bin/env node

/**
 * Script para cargar datos de ejemplo en la base de datos
 */

require("dotenv").config()
const { MongoClient } = require("mongodb")
const fs = require("fs")
const path = require("path")

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://admin:password123@localhost:27017"
const DB_NAME = process.env.DB_NAME || "mi_proyecto_mongo"

async function seedData() {
  let client

  try {
    console.log("🌱 Iniciando carga de datos de ejemplo...")

    client = new MongoClient(MONGODB_URI)
    await client.connect()
    console.log("✅ Conectado a MongoDB")

    const db = client.db(DB_NAME)

    // Cargar datos de clientes
    const clientesPath = path.join(__dirname, "../sample_data/clientes.json")
    if (fs.existsSync(clientesPath)) {
      const clientesData = JSON.parse(fs.readFileSync(clientesPath, "utf8"))

      // Limpiar colección existente
      await db.collection("clientes").deleteMany({})

      // Insertar nuevos datos
      const result = await db.collection("clientes").insertMany(clientesData)
      console.log(`✅ ${result.insertedCount} clientes insertados`)
    }

    // Datos de productos de ejemplo
    const productos = [
      {
        nombre: "Laptop Gaming",
        categoria: "Electrónicos",
        precio: 1299.99,
        stock: 15,
        especificaciones: {
          procesador: "Intel i7",
          ram: "16GB",
          almacenamiento: "512GB SSD",
        },
        activo: true,
      },
      {
        nombre: "Mouse Inalámbrico",
        categoria: "Accesorios",
        precio: 29.99,
        stock: 50,
        especificaciones: {
          tipo: "Óptico",
          conectividad: "Bluetooth",
          bateria: "Recargable",
        },
        activo: true,
      },
      {
        nombre: "Monitor 4K",
        categoria: "Electrónicos",
        precio: 399.99,
        stock: 8,
        especificaciones: {
          tamaño: "27 pulgadas",
          resolucion: "3840x2160",
          tipo_panel: "IPS",
        },
        activo: true,
      },
    ]

    await db.collection("productos").deleteMany({})
    const productosResult = await db.collection("productos").insertMany(productos)
    console.log(`✅ ${productosResult.insertedCount} productos insertados`)

    // Generar órdenes de ejemplo
    const clientes = await db.collection("clientes").find({}).toArray()
    const productosInsertados = await db.collection("productos").find({}).toArray()

    const ordenes = []
    for (let i = 0; i < 20; i++) {
      const cliente = clientes[Math.floor(Math.random() * clientes.length)]
      const producto = productosInsertados[Math.floor(Math.random() * productosInsertados.length)]
      const cantidad = Math.floor(Math.random() * 3) + 1

      ordenes.push({
        cliente_id: cliente._id,
        productos: [
          {
            producto_id: producto._id,
            nombre: producto.nombre,
            precio: producto.precio,
            cantidad: cantidad,
          },
        ],
        total: producto.precio * cantidad,
        fecha_orden: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
        estado: ["pendiente", "procesando", "enviado", "entregado"][Math.floor(Math.random() * 4)],
      })
    }

    await db.collection("ordenes").deleteMany({})
    const ordenesResult = await db.collection("ordenes").insertMany(ordenes)
    console.log(`✅ ${ordenesResult.insertedCount} órdenes insertadas`)

    console.log("\n🎉 ¡Datos de ejemplo cargados exitosamente!")
  } catch (error) {
    console.error("❌ Error cargando datos:", error.message)
    process.exit(1)
  } finally {
    if (client) {
      await client.close()
    }
  }
}

if (require.main === module) {
  seedData()
}

module.exports = { seedData }
