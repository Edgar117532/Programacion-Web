#!/usr/bin/env node

/**
 * Script para materializar datos de órdenes con información agregada
 */

require("dotenv").config()
const { MongoClient } = require("mongodb")

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://admin:password123@localhost:27017"
const DB_NAME = process.env.DB_NAME || "mi_proyecto_mongo"

async function materializeOrders() {
  let client

  try {
    console.log("🔄 Materializando órdenes...")

    client = new MongoClient(MONGODB_URI)
    await client.connect()
    const db = client.db(DB_NAME)

    // Pipeline de agregación para materializar órdenes
    const pipeline = [
      {
        $lookup: {
          from: "clientes",
          localField: "cliente_id",
          foreignField: "_id",
          as: "cliente_info",
        },
      },
      {
        $unwind: "$cliente_info",
      },
      {
        $project: {
          orden_id: "$_id",
          cliente_nombre: "$cliente_info.nombre",
          cliente_email: "$cliente_info.email",
          cliente_ciudad: "$cliente_info.direccion.ciudad",
          productos: 1,
          total: 1,
          fecha_orden: 1,
          estado: 1,
          año: { $year: "$fecha_orden" },
          mes: { $month: "$fecha_orden" },
          cantidad_productos: { $size: "$productos" },
        },
      },
    ]

    // Eliminar colección materializada anterior
    try {
      await db.collection("materialized_orders").drop()
    } catch (error) {
      // La colección no existe, continuar
    }

    // Ejecutar agregación y guardar resultados
    const result = await db.collection("ordenes").aggregate(pipeline).toArray()

    if (result.length > 0) {
      await db.collection("materialized_orders").insertMany(result)
      console.log(`✅ ${result.length} órdenes materializadas`)

      // Crear índices en la colección materializada
      await db.collection("materialized_orders").createIndex({ cliente_email: 1 })
      await db.collection("materialized_orders").createIndex({ año: 1, mes: 1 })
      await db.collection("materialized_orders").createIndex({ estado: 1 })

      console.log("✅ Índices creados en colección materializada")
    } else {
      console.log("⚠️  No hay órdenes para materializar")
    }

    console.log("\n🎉 ¡Materialización completada!")
  } catch (error) {
    console.error("❌ Error materializando órdenes:", error.message)
    process.exit(1)
  } finally {
    if (client) {
      await client.close()
    }
  }
}

if (require.main === module) {
  materializeOrders()
}

module.exports = { materializeOrders }
