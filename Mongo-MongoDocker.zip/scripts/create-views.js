#!/usr/bin/env node

/**
 * Script para crear vistas en MongoDB
 */

require("dotenv").config()
const { MongoClient } = require("mongodb")

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://admin:password123@localhost:27017"
const DB_NAME = process.env.DB_NAME || "mi_proyecto_mongo"

async function createViews() {
  let client

  try {
    console.log("👁️  Creando vistas...")

    client = new MongoClient(MONGODB_URI)
    await client.connect()
    const db = client.db(DB_NAME)

    // Vista de clientes activos
    try {
      await db.dropCollection("view_active_clients")
    } catch (error) {
      // La vista no existe, continuar
    }

    await db.createCollection("view_active_clients", {
      viewOn: "clientes",
      pipeline: [
        { $match: { activo: true } },
        {
          $project: {
            nombre: 1,
            email: 1,
            telefono: 1,
            ciudad: "$direccion.ciudad",
            fecha_registro: 1,
          },
        },
        { $sort: { fecha_registro: -1 } },
      ],
    })

    console.log('✅ Vista "view_active_clients" creada')

    console.log("\n🎉 ¡Vistas creadas exitosamente!")
  } catch (error) {
    console.error("❌ Error creando vistas:", error.message)
    process.exit(1)
  } finally {
    if (client) {
      await client.close()
    }
  }
}

if (require.main === module) {
  createViews()
}

module.exports = { createViews }
