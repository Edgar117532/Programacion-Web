// Script de inicialización para Docker
// Este script se ejecuta automáticamente cuando se inicia el contenedor de MongoDB

var db

print("🚀 Iniciando configuración de base de datos...")

// Cambiar a la base de datos del proyecto
db = db.getSiblingDB("mi_proyecto")

// Crear usuario para la aplicación
db.createUser({
  user: "app_user",
  pwd: "app_password",
  roles: [
    {
      role: "readWrite",
      db: "mi_proyecto",
    },
  ],
})

print("✅ Usuario de aplicación creado")

// Crear colecciones iniciales
db.createCollection("clientes")
db.createCollection("productos")
db.createCollection("ordenes")

print("✅ Colecciones iniciales creadas")

// Insertar datos de muestra si existen
try {
  // Los datos se cargarán desde el volumen montado
  print("📊 Datos de muestra se cargarán desde archivos externos")
} catch (error) {
  print("⚠️ No se pudieron cargar datos de muestra:", error)
}

print("🎉 Configuración inicial completada")
