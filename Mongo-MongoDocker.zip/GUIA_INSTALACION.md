# 🚀 Guía de Instalación - Proyecto MongoDB

## Prerrequisitos

1. **Docker Desktop** instalado y ejecutándose
2. **Node.js** (versión 16 o superior)
3. **npm** o **yarn**

## 📋 Pasos de Instalación

### 1. Instalar dependencias
\`\`\`bash
npm install
\`\`\`

### 2. Levantar MongoDB
**En Windows:**
\`\`\`bash
start-mongodb.bat
\`\`\`

**En Linux/Mac:**
\`\`\`bash
chmod +x start-mongodb.sh
./start-mongodb.sh
\`\`\`

**O manualmente:**
\`\`\`bash
docker-compose up -d mongodb
\`\`\`

### 3. Configurar base de datos
\`\`\`bash
npm run setup
\`\`\`

### 4. Cargar datos de ejemplo
\`\`\`bash
npm run seed
\`\`\`

### 5. Ejecutar consultas de ejemplo
\`\`\`bash
npm run queries
\`\`\`

## 🔧 Comandos Útiles

### MongoDB
\`\`\`bash
# Levantar todos los servicios
docker-compose up -d

# Ver logs de MongoDB
docker-compose logs mongodb

# Conectar a MongoDB shell
docker-compose exec mongodb mongosh -u admin -p password123

# Parar servicios
docker-compose down
\`\`\`

### Scripts del proyecto
\`\`\`bash
npm run setup          # Configurar base de datos
npm run seed           # Cargar datos de ejemplo
npm run queries        # Ejecutar todas las consultas
npm run create-views   # Crear vistas de MongoDB
npm run materialize    # Materializar colecciones
\`\`\`

## 🌐 Interfaces Web

- **Mongo Express**: http://localhost:8081
  - Usuario: `admin`
  - Contraseña: `admin123`

## ❌ Solución de Problemas

### Error: "ECONNREFUSED 127.0.0.1:27017"
1. Verificar que Docker Desktop esté ejecutándose
2. Ejecutar: `docker-compose up -d mongodb`
3. Esperar 10-15 segundos para que MongoDB inicie
4. Verificar con: `docker-compose ps`

### Error: "Authentication failed"
- Las credenciales están en `docker-compose.yml`
- Usuario: `admin`, Contraseña: `password123`

### Puerto 27017 ocupado
\`\`\`bash
# Ver qué proceso usa el puerto
netstat -ano | findstr :27017

# Parar MongoDB local si existe
net stop MongoDB
\`\`\`

## 📁 Estructura del Proyecto

\`\`\`
mi-proyecto-mongo/
├── teoria/respuestas.md           # Documentación teórica
├── queries/                       # Scripts de consultas
├── scripts/                       # Scripts de configuración
├── sample_data/                   # Datos de ejemplo
├── docker-compose.yml             # Configuración Docker
└── GUIA_INSTALACION.md           # Esta guía
