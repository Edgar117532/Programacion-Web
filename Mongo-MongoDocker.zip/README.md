# Mi Proyecto MongoDB

Este proyecto contiene ejemplos prácticos de MongoDB incluyendo operaciones CRUD, agregaciones, índices y vistas.

## Estructura del Proyecto

- `teoria/` - Documentación teórica y conceptos
- `queries/` - Scripts de JavaScript con ejemplos de consultas
- `colecciones/` - Definiciones de vistas y colecciones materializadas
- `sample_data/` - Datos de muestra para testing
- `video/` - Enlaces a recursos multimedia

## Requisitos

- MongoDB 6.0+
- Node.js 16+
- Docker (opcional)

## Instalación

### Con Docker
\`\`\`bash
docker-compose up -d
\`\`\`

### Manual
1. Instalar MongoDB
2. Importar datos de muestra:
\`\`\`bash
mongoimport --db mi_proyecto --collection clientes --file sample_data/clientes.json --jsonArray
\`\`\`

## Uso

Ejecutar los scripts de queries en orden:
\`\`\`bash
node queries/01_insert_documents.js
node queries/02_find_examples.js
node queries/03_update_delete.js
node queries/04_aggregation.js
node queries/05_create_index_and_explain.js
\`\`\`

## Contenido

### Teoría
- Conceptos fundamentales de MongoDB
- Glosario de términos
- Pasos para operaciones comunes

### Queries
- Inserción de documentos
- Consultas y filtros
- Actualizaciones y eliminaciones
- Pipeline de agregación
- Índices y optimización

### Colecciones
- Vista de clientes activos
- Órdenes materializadas para reporting
