"use client"

import  from "../seed-data"

export default function SyntheticV0PageForDeployment() {
  return < />
}