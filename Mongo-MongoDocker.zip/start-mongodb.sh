#!/bin/bash

echo "🚀 Iniciando MongoDB con Docker..."

# Verificar si Docker está ejecutándose
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker no está ejecutándose. Por favor inicia Docker Desktop."
    exit 1
fi

# Levantar MongoDB
echo "📦 Levantando contenedores..."
docker-compose up -d mongodb

# Esperar a que MongoDB esté listo
echo "⏳ Esperando a que MongoDB esté listo..."
sleep 10

# Verificar conexión
echo "🔍 Verificando conexión..."
docker-compose exec mongodb mongosh --eval "db.adminCommand('ping')" > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "✅ MongoDB está ejecutándose correctamente"
    echo "🌐 Mongo Express estará disponible en: http://localhost:8081"
    echo "   Usuario: admin"
    echo "   Contraseña: admin123"
    echo ""
    echo "📝 Ahora puedes ejecutar:"
    echo "   npm run setup"
    echo "   npm run seed"
    echo "   npm run queries"
else
    echo "❌ Error al conectar con MongoDB"
    echo "📋 Logs de MongoDB:"
    docker-compose logs mongodb
fi
